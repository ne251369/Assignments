var appValidation = function() {

  this.get = function() {
    browser.get('https://www.opencart.com/');
  };

  this.clickLoginButton = function() {
	  browser.sleep(15000);
	  element(by.xpath("//a[@class='btn btn-link navbar-btn']")).click();
  }; 
  
  this.enterUserName = function(value) {
     element(by.xpath("//input[@name='email']")).sendKeys(value);
  };

  this.enterPassword = function(value) {
    element(by.xpath("//input[@type='password']")).sendKeys(value);
  };

this.submitButton = function(){
	element(by.xpath("(//div[@id='account-login']//button)[1]")).click();
};

  this.TextInvalidLogin = function() {
    return element(by.xpath("//div[@class='alert alert-danger']")).getText();
  };
  
  
  this.titleValidation = function() {
   return element(by.xpath("//nav//a/img")).getAttribute('title');
  }
};

module.exports = appValidation;
