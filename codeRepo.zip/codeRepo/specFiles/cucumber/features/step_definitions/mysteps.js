var chai = require('chai').use(require('chai-as-promised'));
var expect = chai.expect;

var Logincheck = function() {

   var appValidation = require("C:/Users/Neema/Desktop/codeRepo/specFiles/cucumber/features/step_definitions/stepsFunctions.js")
	var appValidations = new appValidation();
	
  this.Given('Open application url', function (callback) {
	  browser.ignoreSynchronization=true;
	  browser.get('https://www.opencart.com/').then(function(){
       
	    });
		callback();
  });

  this.When('enter invalid values and click on login button and click on login link', function (callback) {
	browser.sleep(5000);
	element(by.xpath("//a[@class='btn btn-link navbar-btn']")).click();
	browser.sleep(5000);
	appValidations.enterUserName("1233334wwe");
	appValidations.enterPassword("12342");
	appValidations.submitButton();
	browser.sleep(5000);
 callback();
  });
  
  this.Then('I should get error message', function (callback) {
	//appValidations.TextInvalidLogin().then(function(qq){
	//	console.log(qq);
	//});
	  expect(appValidations.TextInvalidLogin()).to.eventually.contain("No match for E-Mail and/or Password.").and.notify(callback);
	 
  });
  this.Then('verify the title', function (callback) {
	   expect(appValidations.titleValidation()).to.eventually.contain("OpenCart - Account Login");
	  callback();
  });
};

module.exports = Logincheck;