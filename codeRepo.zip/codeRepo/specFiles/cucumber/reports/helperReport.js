{
  "spec_dir": "spec",
  "spec_files": [
    
	"C:/Users/Neema/Desktop/codeRepo/specFiles/cucumberfeatures/opencartapp.feature"
	
  ],
  "helpers": [
    "helpers/**/*.js"
  ],
  "stopSpecOnExpectationFailure": false,
  "random": false
}
