var configure_report = function(){

                var JsonFormatter = require('cucumber');

                var outputDir = 'Execution';

                var fs = require('fs');

                var sourceJson = './ExecutionReport/';

                this.After(function(scenario, callback) {

                  //if (scenario.isFailed()) {

                                browser.takeScreenshot().then(function(base64png) {

                                  var decodedImage = new Buffer(base64png, 'base64').toString('binary');

                                  scenario.attach(decodedImage, 'image/png');

                                  callback();

                                }, function(err) {

                                  callback(err);

                                });

                // } else {

                                //callback();

                  //}

                });

 

                               

                var createHtmlReport = function (sourceJson) {

                                var reporter = require('cucumber-html-reporter');

                                var options = {

                                                theme: 'bootstrap',

                                                jsonFile: sourceJson, 

                                                output:  outputDir+'index.html', 

                                                reportSuiteAsScenarios: true,

                                                launchReport: true

                                };

 

                   reporter.generate(options);

                };

               

                //????jsonFormatter = new JsonFormatter();

                var JsonFormatter = JsonFormatter.Listener.JsonFormatter();

                JsonFormatter.log = function(string) {

                  if (!fs.existsSync(outputDir)) {

                                fs.mkdirSync(outputDir);

                  }

 

                  var targetJson = outputDir + 'cucumber_report.json';

                  fs.writeFile(targetJson, string, function(err) {

                                if (err) {

                                  console.log('Failed to save cucumber test results to json file.');

                                  console.log(err);

                                } else {

                                  createHtmlReport(targetJson);

                                }

                  });

                };

 

                this.registerListener(JsonFormatter);

};

module.exports = configure_report;