var Jasmine = require('jasmine');
var HtmlReporter = require('jasmine-pretty-html-reporter').Reporter;
var jasmine = new Jasmine();
var path = require('path');

exports.config = {
  framework: 'jasmine',
  seleniumAddress: 'http://localhost:4444/wd/hub',
  specs: ['spec.js']
}


jasmine.loadConfigFile('C:/Users/Neema/Desktop/codeRepo/specFiles/cucumber/reports/jasmine.json');

// options object
jasmine.addReporter(new HtmlReporter({
  path: path.join('C:/Users/Neema/Desktop/codeRepo/specFiles/cucumber/reports','results')
}));

jasmine.execute();
