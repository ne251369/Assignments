
var dataNeeded = function () {
	var statusExpected = "200";
	var userID = "1";
	var postURI = 'https://jsonplaceholder.typicode.com/posts';
	var postMethod = 'POST';
	var postStatus = "201";
	var postUserId = "101";
	
};

module.exports = new dataNeeded;