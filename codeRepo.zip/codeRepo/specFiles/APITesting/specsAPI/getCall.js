//4.	Make a GET call. Assert the response status code and userId
//Test data - https://jsonplaceholder.typicode.com/posts/1

var fs = require('fs');
var request = require('request-promise');
var assert = require('assert');
var dataNeeded = require('C:/Users/Neema/Desktop/codeRepo/specFiles/APITesting/testDataFiles/dataNeeded.js');

	'use strict';
describe("Get Call", function(){
	it("Get call test case", function(){
		
request.get(
	'https://jsonplaceholder.typicode.com/posts/1',
	{json: true },
	function (error, response, body) {
		console.log(response.statusCode);
		console.log(body.userId);
		assert.equal(response.statusCode, dataNeeded.statusExpected);
		assert.equal(body.userId,dataNeeded.userID);
	}
	);
});
it("Post call test case", function(){	
	var GETResponse = {
		method:dataNeeded.postMethod,
		uri: 'https://jsonplaceholder.typicode.com/posts',
		headers : {
			"Content-type": "application/json; charset=UTF-8"
		},			
		body: {
			"title": "foo",
			"body": "bar",
			"userId": "1"
		},
		json:true
	};
	request(GETResponse).then(function (parseBody) {
		assert.equal(parseBody.id, dataNeeded.postUserId);
	});
	request.post(
		'https://jsonplaceholder.typicode.com/posts',
		{json: true },
		function (error, response, body) {
			console.log(response.statusCode);
			assert.equal(response.statusCode, dataNeeded.postStatus);
		}
	);
});
});