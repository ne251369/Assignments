//process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

const soapRequest = require('easy-soap-request');

const fs = require('fs');

var assert = require('assert');

 

// example data

const url = 'http://www.example.org';

const headers = {

  'user-agent': 'sampleTest',

  'request':'POST /InStock HTTP/1.1',

'Host': 'www.example.org',

'Content-Type': 'application/soap+xml; charset=utf-8',

'Content-Length': 'nnn',

  'soapAction': 'https://clicktime.symantec.com/a/1/JIwp3fsT4SqKy3Ceczaw3E0_5tUSWKxCOgFmnCkd3Ec=?d=wnP_oFkkwGVYG7vs0E0T_7CDtq1f2XHtlaL-yP2y_-KdaTEe524FF9p2sNpf4N_D6OeSKUfOZPzBZqs_VgrHk9Qgh4t2Ik_DT5_jLPZ-rgy4WLSXrBLIUitwqgJ3F_5WXiibeUBp8q1Bhyt4Q4vsngufxVLyrEGWM-8xoJuG7-X6jJpiwEzVYArDBijGhkLT20bM2e1NtFAoVLL3_T1hjuWrNgVQEO7UHBWdRXXf_s-t5Zta1X6atFEPtu1igVqpRjV7Ndmq2cDwo-jjzxJEC5h0FFCtbk8vCAT8ROe48iz9RqyfMA9G1CyTkYxaJy5nMz0jOp31dDrD-KO9u97NMu-h87V0QrAnygnDLPUCX_fWZK6d-Tmzi88bGpSlCBT1BVyPWBglqucxNQdEFAId1Fq-UpAdCTNXC-93&u=http%3A%2F%2Fwww.example.org%2Fstock%2522'

};

const xml = fs.readFileSync('soapRequest.xml', 'utf-8'); 
//const xml = fs.readFile('soapRequest.xml', 'utf-8'); 

(async () => {

                try{

  const { response } = await soapRequest(url, headers, xml, 10000); // Optional timeout parameter(milliseconds)

  const { body, statusCode } = response;

  //console.log(body);

  console.log(statusCode);

  assert(statusCode == 200,'Bad request performed');

                }

                catch(e){

                                console.log('error'+e);

                }

})();