var fs = require ('fs');
var assert = require('assert');
var request = require('request-promise');

	'use strict';
var GETResponse = {
	method:'POST',
	uri: 'https://jsonplaceholder.typicode.com/posts',
	headers : {
		"Content-type": "application/json; charset=UTF-8"
	},			
	body: {
		"title": "foo",
		"body": "bar",
		"userId": "1"
	},
	json:true
};
request(GETResponse).then(function (parseBody) {
	assert.equal(parseBody.id, "101");
});
request.post(
	'https://jsonplaceholder.typicode.com/posts',
	{json: true },
	function (error, response, body) {
		console.log(response.statusCode);
		assert.equal(response.statusCode, "201");
	}
);