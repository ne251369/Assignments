// Import fs module
const fs = require('fs');
parseString = require('xml2js').parseString;
// Read the source file.
var file2 = 'C:/Users/Neema/Desktop/codeRepo/testData/source.json';
fs.readFile('C:/Users/Neema/Desktop/codeRepo/testData/source.json', ( err, json ) => {
	console.log(json);
	var file = require(file2);
	console.log(file2);
	file.name = "Wipro Ltd";
    // write to file
    fs.writeFile('C:/Users/Neema/Desktop/codeRepo/testData/result.json', JSON.stringify(file ), ( err ) => {
		if( err ) {
			console.log( err );
		}
		else console.log('Done!');
    });
});